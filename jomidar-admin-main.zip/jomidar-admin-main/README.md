## Support

https://discord.gg/9m2KTFskjx

https://discord.gg/9m2KTFskjx

## Installation
Download then drag and drop the script into your folder. Make sure to run the SQL.

IMP !! go to server.cfg and set steam web api

```set steam_webApiKey "yourapikey"```

## Show Case
https://www.youtube.com/watch?v=fy68G2Yxjtg

## Perms

```add_principal identifier.YOUR_IDENTIFIER qbcore.god```

## Logs

```exports['jomidar-admin']:CreateLog('Inventory', 'Added item or something')```

```exports['jomidar-admin']:CreateLog('Inventory', 'Added item or something', 'DATA HERE')```

## Credits 
mercy-Collective
